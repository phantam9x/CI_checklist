<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$autoload['packages'] = array();

$autoload['libraries'] = array('fb','form_validation','database','permission');

$autoload['drivers'] = array();

$autoload['helper'] = array('url','data','form','message','user');

$autoload['config'] = array('facebook');

$autoload['language'] = array();

$autoload['model'] = array();
