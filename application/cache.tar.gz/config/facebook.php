<?php 

$config['app_id']  = '1973768959539152';
$config['app_secret'] = '430269974aac32191b9d3b6172775d95';
$config['graph_version'] = 'v2.10';
$config['permissions'] = ['email', 'user_likes'];