<?php 

if(!function_exists('dd')) {
	function dd($data) {
		echo '<pre>';
		print_r($data);
		echo '</pre>';
		exit;
	}
}