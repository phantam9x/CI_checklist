<div class="wp-message-session">
	<?=get_message(); ?>
</div>